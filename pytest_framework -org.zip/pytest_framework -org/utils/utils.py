import configparser
import json
import os

import boto3
import pandas as pd

AWS_ACCESS_KEY_ID = os.environ['AWS_ACCESS_KEY_ID']
AWS_SECRET_ACCESS_KEY = os.environ['AWS_SECRET_ACCESS_KEY']
AWS_SESSION_TOKEN = os.environ['AWS_SESSION_TOKEN']


def get_param_value(param_name):
    ssm = boto3.client('ssm',
                       region_name="us-east-1",
                       aws_access_key_id=AWS_ACCESS_KEY_ID,
                       aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
                       aws_session_token=AWS_SESSION_TOKEN
                       )
    try:
        parameter = ssm.get_parameter(Name=f'{param_name}', WithDecryption=True)        
    except Exception as error:
        print(error)
        raise Exception(f"{param_name} parameter not found !!")
    return parameter['Parameter']['Value']


def csv_to_dict(table_name):
    df = pd.read_csv(f"./config/stm_tables/{table_name}")
    df['Type'] = df['Type'].str.lower()
    df['Name'] = df['Name'].str.lower()
    df['Type'].replace('stringtype', 'string', inplace=True)
    df['Type'].replace('booleantype', 'boolean', inplace=True)
    df['Type'].replace('integertype', 'int', inplace=True)
    df['Type'].replace('datetype', 'date', inplace=True)
    df['Type'].replace('decimaltype', 'decimal', inplace=True)
    df['Type'].replace('biginttype', 'bigint', inplace=True)
    df['Type'].replace('doubletype', 'double', inplace=True)
    df['Type'].replace('string', 'string', inplace=True)
    df['Type'].replace('boolean', 'boolean', inplace=True)
    df['Type'].replace('integer', 'int', inplace=True)
    df['Type'].replace('date', 'date', inplace=True)
    df['Type'].replace('decimal', 'decimal', inplace=True)
    df['Type'].replace('bigint', 'bigint', inplace=True)
    df['Type'].replace('double', 'double', inplace=True)
    df.loc[df["Type"] == "decimal", "Type"] = df["Type"] + \
        "(" + df["Max Length"] + ")"
    df_new = df[['Name', 'Type']]
    df_new = df_new.dropna()
    mapping_dict = df_new.to_dict('records')
    return mapping_dict


def read_config_list(header, key, filename):
    config = configparser.ConfigParser(allow_no_value=True)
    config.read(filename)
    return json.loads(config.get(header, key))


def read_config_values(header, key, filename):
    config = configparser.ConfigParser(allow_no_value=True)
    config.read(filename)
    return config.get(header, key)


def read_config_section(filename):
    config = configparser.ConfigParser(allow_no_value=True)
    config.read(filename)
    return config.sections()
