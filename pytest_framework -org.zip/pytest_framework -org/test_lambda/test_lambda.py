import json
import boto3
import pytest

from ..utils.utils import read_config_list, read_config_values

sts_client = boto3.client('sts')
account_id = sts_client.get_caller_identity()["Account"]

config_lambda_function = read_config_list(
    header="lambda_functions", key="function", filename="./config/lambda_config.ini")

lambda_li = []
def test_check_lambda():
    lambda_client = boto3.client('lambda', region_name='us-east-1')
    lambda_response = lambda_client.get_function(FunctionName=config_lambda_function)
    lambda_function = lambda_response['Configuration']['FunctionName']
    assert config_lambda_function == lambda_function
