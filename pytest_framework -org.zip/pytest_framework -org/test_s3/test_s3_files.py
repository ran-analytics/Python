import json
import os

import boto3
import pandas as pd
import pytest

from ..utils.utils import get_param_value, read_config_list

config_lambda = read_config_list(
    header="s3-lambda", key="lambda", filename="./config/s3_config.ini")
config_glue_scripts = read_config_list(
    header="s3-glue", key="scripts", filename="./config/s3_config.ini")
config_glue_sql = read_config_list(
    header="s3-glue-sql", key="sql", filename="./config/s3_config.ini")
pipeline_bucket = read_config_list(
    header="s3-pipeline", key="pipeline", filename="./config/s3_config.ini")
config_driver_val = read_config_list(
    header="s3-drivers", key="driver", filename="./config/s3_config.ini")

@pytest.mark.parametrize("file_lambda", config_lambda)
def test_s3_bucket_lambda(file_lambda, stage):
    bucket = get_param_value('/s3/bucket/lii-data-pipeline/name')
    s3 = boto3.client('s3',
                      region_name="us-east-1"
                      )
    results = s3.list_objects_v2(
        Bucket=bucket, Prefix=f'{pipeline_bucket}/lambda/{file_lambda}')
    if 'Contents' not in results:
        raise Exception(
            f"Filename {file_lambda} not found in s3 bucket s3://lii-data-pipeline-{stage}/{pipeline_bucket}/lambda/")

@pytest.mark.parametrize("file_scripts", config_glue_scripts)
def test_s3_bucket_scripts(file_scripts,stage):
    bucket = get_param_value('/s3/bucket/lii-data-pipeline/name')
    s3 = boto3.client('s3',
                      region_name="us-east-1"
                      )
    results = s3.list_objects_v2(
        Bucket=bucket, Prefix=f'{pipeline_bucket}/glue/scripts/{file_scripts}')
    if 'Contents' not in results:
        raise Exception(
            f"Filename {file_scripts} not found in s3 bucket s3://lii-data-pipeline-{stage}/{pipeline_bucket}/glue/scripts/")

@pytest.mark.parametrize("file_sql", config_glue_sql)
def test_s3_bucket_sql(file_sql, stage):
    bucket = get_param_value('/s3/bucket/lii-data-pipeline/name')
    s3 = boto3.client('s3',
                      region_name="us-east-1"
                      )
    results = s3.list_objects_v2(
        Bucket=bucket, Prefix=f'{pipeline_bucket}/glue/sql/{file_sql}')
    if 'Contents' not in results:
        raise Exception(
            f"Filename {file_sql} not found in s3 bucket s3://lii-data-pipeline-{stage}/{pipeline_bucket}/glue/sql/")

def test_s3_bucket_sql(stage):
    bucket = get_param_value('/s3/bucket/lii-data-pipeline/name')
    s3 = boto3.client('s3',
                      region_name="us-east-1"
                      )
    results = s3.list_objects_v2(
        Bucket=bucket, Prefix=f'drivers/db2/{config_driver_val}')
    if 'Contents' not in results:
        raise Exception(
            f"Filename {config_driver_val} not found in s3 bucket s3://lii-data-pipeline-{stage}/drivers/db2")
