import json
import boto3
import pytest

from ..utils.utils import read_config_list, read_config_values

sts_client = boto3.client('sts')
account_id = sts_client.get_caller_identity()["Account"]

config_glue_jobs = read_config_list(
    header="glue_jobs", key="jobs", filename="./config/glue_config.ini")

@pytest.mark.parametrize("glue_jobs", config_glue_jobs)
def test_check_sf(glue_jobs):
    glue_client = boto3.client('glue', region_name='us-east-1')
    glue_response = glue_client.list_jobs(MaxResults=100)
    if glue_jobs not in glue_response['JobNames']:
        raise Exception(
            f"{glue_jobs} glue job not found !!")
