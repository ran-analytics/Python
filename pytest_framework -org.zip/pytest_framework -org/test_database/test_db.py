import boto3
import pytest

from ..utils.utils import read_config_list, read_config_values

database_name = read_config_values(header="database", key="database",
                                   filename="./config/db_config.ini")
database_name = database_name.replace('"', '')
config_tables = read_config_list(
    header="database", key="tables", filename="./config/db_config.ini")

sts_client = boto3.client('sts')
account_id = sts_client.get_caller_identity()["Account"]


def test_check_database():
    session = boto3.Session()
    glue_client = session.client('glue', region_name='us-east-1')
    response = glue_client.get_databases(
        CatalogId=account_id
    )
    assert database_name in [i['Name'] for i in response['DatabaseList']]


@pytest.mark.parametrize("table_name", config_tables)
def test_check_tables(table_name):
    session = boto3.Session()
    glue_client = session.client('glue', region_name='us-east-1')
    response = glue_client.get_tables(
        CatalogId=account_id,
        DatabaseName=database_name)
    assert table_name in [i['Name'] for i in response['TableList']]
