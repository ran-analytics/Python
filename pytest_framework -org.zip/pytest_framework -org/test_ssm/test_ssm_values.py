import pytest

from ..utils.utils import get_param_value, read_config_list

config_environment = read_config_list(
    header="common_param", key="stage", filename="./config/param_config.ini")
config_table_names = read_config_list(
    header="table_name", key="table_names", filename="./config/param_config.ini")
config_rank_key = read_config_list(
    header="table_param", key="rank_key", filename="./config/param_config.ini")
config_sort_key = read_config_list(
    header="table_param", key="sort_key", filename="./config/param_config.ini")
config_partition_look_up_days = read_config_list(
    header="table_param", key="partition_look_up_days", filename="./config/param_config.ini")

config_rank_key_value = read_config_list(
    header="table_param", key="rank_key_value", filename="./config/param_config.ini")
config_sort_key_value = read_config_list(
    header="table_param", key="sort_key_value", filename="./config/param_config.ini")


def test_environment_check(stage):
    parameter = get_param_value(config_environment)
    assert parameter == stage

@pytest.mark.parametrize("file_tables", config_table_names)
def test_table_param_rank_key(file_tables):
    rank_key = config_rank_key.replace("table_name", file_tables)
    key_index = config_table_names.index(file_tables)
    parameter = get_param_value(rank_key)
    assert parameter == config_rank_key_value[key_index]

@pytest.mark.parametrize("file_tables", config_table_names)
def test_table_param_sort_key(file_tables):
    sort_key = config_sort_key.replace("table_name", file_tables)
    parameter = get_param_value(sort_key)
    assert parameter == config_sort_key_value

@pytest.mark.parametrize("file_tables", config_table_names)
def test_table_param_partition(file_tables):
    partition_look_up_days = config_partition_look_up_days.replace(
        "table_name", file_tables)
    parameter = get_param_value(partition_look_up_days)
    