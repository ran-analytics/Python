
### Please follow the below commands to test resources.

0. #### To run all the test cases
    ```
    pytest --stage=test
    ```
1. #### To run all the test cases for specific resource and return all the failure.
    ```
    pytest <test_folder_name> --stage=<env>
    ```
    ```
    pytest test_ssm --stage=test
    pytest test_s3 --stage=test
    pytest test_athena --stage=test
    pytest test_database --stage=test
    pytest test_iam --stage=test
    pytest test_lambda --stage=test
    pytest test_stepfunction --stage=test
    pytest test_eventbridge --stage=test
    pytest test_glue --stage=test
    ```
2. #### To Run all the test cases for specific resource and skips the rest when one or two of them failed.

    #### stop after first failure:
    ```
    pytest -x <test_folder_name> --stage=<env>
    ```
    #### stop after two failures:
    ```
    pytest --maxfail=2 <test_folder_name> --stage=<env> 
    ```
    ```
    pytest -x test_ssm --stage=test
    pytest -x test_s3 --stage=test
    pytest -x test_athena --stage=test
    pytest -x test_database --stage=test
    pytest -x test_iam --stage=test
    pytest -x test_lambda --stage=test
    pytest -x test_stepfunction --stage=test
    pytest -x test_eventbridge --stage=test
    pytest -x test_glue --stage=test
    ```
3. #### To run a specific test case.
    ```
    pytest -k <test_case_name> --stage=<env>
    ```
    ```
    pytest -k test_environment_check --stage=test
    pytest -k test_table_param_rank_key --stage=test
    ```
