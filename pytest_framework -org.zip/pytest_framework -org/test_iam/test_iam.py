import json

import boto3
import pytest

from ..utils.utils import (read_config_list, read_config_section,
                           read_config_values)

sts_client = boto3.client('sts')
account_id = sts_client.get_caller_identity()["Account"]
iam = boto3.client('iam')
sections = read_config_section(filename="./config/iam_config.ini")
role_names = []
for sec in sections:
    iamrole_name = read_config_values(
        header=sec, key='name', filename='./config/iam_config.ini')
    iamrole_name = iamrole_name.replace('"', '')
    role_names.append(iamrole_name)


@pytest.mark.parametrize("role_name", role_names)
def test_iam_role(role_name):
    try:
        response = iam.get_role(
            RoleName=role_name
        )
    except:
        raise Exception(
            f"Role cannot be found! Please check the following {role_name} role in IAM role")


@pytest.mark.parametrize("role_name", role_names)
def test_iam_policy(role_name):
    policy_arn = f"arn:aws:iam::{account_id}:policy/{role_name}"
    try:
        response = iam.get_policy(
            PolicyArn=policy_arn
        )
        policy_version = iam.get_policy_version(
            PolicyArn=policy_arn,
            VersionId=response['Policy']['DefaultVersionId']
        )
    except:
        raise Exception(
            f"Policy cannot be found! Please check the following {policy_arn} policy")
