import os
import sys

import boto3
import pytest

from ..utils.utils import csv_to_dict, read_config_values

database_name = read_config_values(header="database", key="database",
                                   filename="./config/db_config.ini")
database_name = database_name.replace('"', '')

AWS_ACCESS_KEY_ID = os.environ['AWS_ACCESS_KEY_ID']
AWS_SECRET_ACCESS_KEY = os.environ['AWS_SECRET_ACCESS_KEY']
AWS_SESSION_TOKEN = os.environ['AWS_SESSION_TOKEN']

tablenames = os.listdir(path="./config/stm_tables")
@pytest.mark.parametrize("tablename", tablenames)
def test_athena_query(tablename):
    table_name = tablename.split(".")[0]
    table_csv_to_dict = csv_to_dict(tablename)
    client = boto3.client('athena', region_name='us-east-1')
    response = client.get_table_metadata(
        CatalogName='AwsDataCatalog',
        DatabaseName=database_name,
        TableName=f"{table_name}",
    )
    table_columns = response['TableMetadata']['Columns']
    table_partition = response['TableMetadata']['PartitionKeys']
    for tb in table_columns:
        tb.pop('Comment', None)
    for tp in table_partition:
        tp.pop('Comment', None)
    table_columns.append(table_partition[0])

    mapping_stm_errors = []
    mapping_athena_errors = []
    for i in table_csv_to_dict:
        if i not in table_columns:
            mapping_stm_errors.append(i)
    for i in table_columns:
        if i not in table_csv_to_dict:
            mapping_athena_errors.append(i)
    if mapping_stm_errors != [] or mapping_athena_errors != []:
        raise Exception(
            f"Schema mismatch in '{table_name} table'! Please check the below columns in Athena & STM to resolve: \n STM = {mapping_stm_errors} \n ATHENA = {mapping_athena_errors} ")
