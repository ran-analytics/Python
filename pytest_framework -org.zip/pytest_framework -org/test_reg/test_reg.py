import time
import boto3
import os
import pytest
#from selenium import webdriver
''''
# Set the access key and session token
access_key = os.environ['AWS_ACCESS_KEY_ID']
secret_key = os.environ['AWS_SECRET_ACCESS_KEY']
session_token = os.environ['AWS_SESSION_TOKEN']

print("the access key is", access_key)
print("secret_key", secret_key)
# Create a boto3 session with the access key, secret key, and session token
session = boto3.Session(
    aws_access_key_id=access_key,
    aws_secret_access_key=secret_key,
    aws_session_token=session_token
)'''
# from ..utils.utils import csv_to_dict, read_config_values

# set region and  list buckets
region = 'us-east-2'

# Connect to AWS Athena
athena = boto3.client('athena')

# Read the list of queries from the input SQL file
with open ("C:/Livingston/Automation/python/athena/queries.sql") as f:
#with open("queries.sql",'r') as f:
    queries = f.read().split(";")   
#print (queries)
# Loop through the list of queries and run each one
for query in queries:
    # Skip empty queries
    if not query:
        continue 
# Loop through the list of queries
start_time = time.time()
for query in queries:
    # Start a query execution
    response = athena.start_query_execution(
        QueryString=query
    ,ResultConfiguration={"OutputLocation": "s3://lii-data-athena-results-test/auto"}
    )
#print("Query execution started:", response["QueryExecutionId"])
#print("Total Queries executed".format(len(queries)))
        
    # Get the query results
elapsed_time = time.time() - start_time
print(f"Total Queries executed: {len(queries)}","in",elapsed_time,"seconds")
