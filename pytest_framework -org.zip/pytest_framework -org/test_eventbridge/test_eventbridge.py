import json
import boto3
import pytest

from ..utils.utils import read_config_list, read_config_values

sts_client = boto3.client('sts')
account_id = sts_client.get_caller_identity()["Account"]

config_eb_function = read_config_list(
    header="event_bridge", key="eb", filename="./config/eventbridge_config.ini")

eb_li = []
@pytest.mark.parametrize("event_bridge", config_eb_function)
def test_check_sf(event_bridge):
    eb_client = boto3.client('events', region_name='us-east-1')
    eb_response = eb_client.list_rules()
    for response in eb_response['Rules']:
        eb_li.append(response['Name'])
    if event_bridge not in eb_li:
        raise Exception(
            f"{event_bridge} EventBridge not found !!")
