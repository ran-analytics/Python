import json
import boto3
import pytest

from ..utils.utils import read_config_list, read_config_values

sts_client = boto3.client('sts')
account_id = sts_client.get_caller_identity()["Account"]

config_sf_function = read_config_list(
    header="step_functions", key="sf", filename="./config/stepfunction_config.ini")

sf_li = []
@pytest.mark.parametrize("step_functions", config_sf_function)
def test_check_sf(step_functions):
    sf_client = boto3.client('stepfunctions', region_name='us-east-1')
    sf_response = sf_client.list_state_machines()
    for response in sf_response['stateMachines']:
        sf_li.append(response['name'])
    if step_functions not in sf_li:
        raise Exception(
            f"{step_functions} step function not found !!")
