import pytest


def pytest_addoption(parser):
    parser.addoption(
        "--stage", action="store", help="dev test qa prod", required=True
    )


@pytest.fixture()
def stage(request):
    return request.config.getoption("--stage")
